### Argument

An argument is a value passed as an input to a function and can be either a primitive or an object.
In JavaScript, functions can also be passed as arguments to other functions.
