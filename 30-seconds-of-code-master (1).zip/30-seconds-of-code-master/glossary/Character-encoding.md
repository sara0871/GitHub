### Character encoding

A character encoding defines a mapping between bytes and text, specifying how the sequenece of bytes should be interpreted.
Two commonly used character encodings are ASCII and UTF-8.
