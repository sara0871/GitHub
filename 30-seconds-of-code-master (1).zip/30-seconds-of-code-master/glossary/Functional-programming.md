### Functional programming

Functional programming is a paradigm in which programs are built in a declarative manner using pure functions that avoid shared state and mutable data. 
Functions that always return the same value for the same input and don't produce side effects are the pillar of functional programming.
