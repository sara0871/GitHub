### HTML

HTML stands for HyperText Markup Language and is a language used to structure web pages.
HTML documents are plaintext documents structured with elements, which are surrounded by `<>` tags and optionally extended with attributes.
