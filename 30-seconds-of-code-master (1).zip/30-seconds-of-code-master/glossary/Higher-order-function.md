### Higher-order function

Higher-order functions are functions that either take other functions as arguments, return a function as a result, or both.
