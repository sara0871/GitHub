### Integer

Integers are one of the primitive data types in Javascript.
They represent a numerical value that has no fractional component.
