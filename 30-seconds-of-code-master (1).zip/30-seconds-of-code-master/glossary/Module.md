### Module

Modules are independent, self-contained pieces of code that can be incorporated into other pieces of code.
Modules improve maintainability and reusability of the code.
