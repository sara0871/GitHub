### Mutable value

Mutable value is a type of variable that can be changed once created.
Objects are mutable as their state can be modified after they are created.
Primitive values are not mutable as we perform reassignment once we change them.
