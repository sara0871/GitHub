### Node.js

Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine.
Node.js can execute JavaScript code outside of the browser and can be used to develop web backends or standalone applications.
