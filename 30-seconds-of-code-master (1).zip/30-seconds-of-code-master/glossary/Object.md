### Object

Objects are data structures that contain data and instructions for working with the data.
Objects consist of key-value pairs, where the keys are alphanumeric identifiers and the values can either be primitives or objects.
JavaScript functions are also objects.
