### Prepared statements

In databases management systems, prepared statements are templates that can be used to execute queries with the provided values substituting the template's parameters.
Prepared statements offer many benefits, such as reusability, maintainability and higher security.
