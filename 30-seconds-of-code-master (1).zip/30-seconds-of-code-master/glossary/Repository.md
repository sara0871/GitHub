### Repository

In a version control system, a repository (or repo for short) is a data structure that stores metadata for a set of files (i.e. a project).
