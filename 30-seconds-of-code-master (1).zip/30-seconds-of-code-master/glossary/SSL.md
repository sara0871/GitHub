### SSL

Secure Sockets Layer, commonly known as SSL or TLS, is a set of protocols and standards for transferring private data across the Internet.
SSL uses a cryptographic system that uses two keys to encrypt data.
