### Scope

Each function has its own scope, and any variable declared within that function is only accessible from that function and any nested functions.
