### URL

URL stands for Uniform Resource Locator and is a text string specifying where a resource can be found on the Internet.
In the HTTP protocol, URLs are the same as web addresses and hyperlinks.
