### WebAssembly

WebAssembly (WA) is a web standard that defines an assembly-like text format and corresponding binary format for executalbe code in web pages.
WebAssembly is meant to complement JavaScript and improve its performance to match native code performance.
