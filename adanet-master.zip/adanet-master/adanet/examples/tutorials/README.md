## Tutorials

Welcome to `adanet`! For a tour of this python package's capabilities, please work through the following notebooks:

1. [The AdaNet objective](./adanet_objective.ipynb)
1. [Customizing AdaNet](./customizing_adanet.ipynb)
