module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/*.test.js'],
  setupTestFrameworkScriptFile: './setupOutputTests.js',
};
