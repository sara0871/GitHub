import React, { Component } from 'react';

function foo() {
  const a = b;
}

class App extends Component {
  render() {
    return <div />;
  }
}

export default App;
