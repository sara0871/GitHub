'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
function foo() {
  console.log('bar');
}

exports.foo = foo;

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlc3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxTQUFTLEdBQVQsR0FBZTtBQUNiLFVBQVEsR0FBUixDQUFZLEtBQVo7QUFDRDs7UUFFUSxHLEdBQUEsRyIsImZpbGUiOiJzdGRvdXQiLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBmb28oKSB7XG4gIGNvbnNvbGUubG9nKCdiYXInKVxufVxuXG5leHBvcnQgeyBmb28gfVxuIl19
