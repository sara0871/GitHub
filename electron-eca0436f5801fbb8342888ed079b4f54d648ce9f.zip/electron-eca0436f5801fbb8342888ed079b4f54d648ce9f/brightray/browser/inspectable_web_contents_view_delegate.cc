#include "brightray/browser/inspectable_web_contents_view_delegate.h"

namespace brightray {

gfx::ImageSkia InspectableWebContentsViewDelegate::GetDevToolsWindowIcon() {
  return gfx::ImageSkia();
}

}  // namespace brightray

