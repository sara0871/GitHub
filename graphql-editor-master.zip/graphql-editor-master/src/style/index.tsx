import { cssRaw } from 'typestyle';
cssRaw(`
body{
    font-family: 'Roboto', 'Helvetica Neue', Helvetica, Arial, sans-serif;
}
`);
