# Night Blue theme for iTerm
You can install the theme from [here](https://cdn.rawgit.com/nikitavoloboev/my-mac-os/master/iterm/Night%20Blue.itermcolors) and open it in iTerm. Here is how it looks:

![](https://i.imgur.com/Emw7NAj.png)

It goes well with [Pure Zsh plugin](https://github.com/sindresorhus/pure) and [Night Blue theme for Vim](https://github.com/nikitavoloboev/night-blue-vim#readme).

![](https://i.imgur.com/DR2E94n.png)