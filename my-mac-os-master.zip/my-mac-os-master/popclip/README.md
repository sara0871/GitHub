# PopClip extensions

You can install PopClip extensions I use by cloning the repository and in PopClip dir, double clicking on the extensions you want to install to PopClip.

I used [PopMaker](http://brettterpstra.com/2014/05/12/popmaker-popclip-extension-generator/) to create the simple web searches extensions.

Here are all the extensions I have activated:

![](https://i.imgur.com/3x35mIC.png)
