RunCommand
==============

Run Terminal Command extension for PopClip.

One can choose either Terminal or iTerm2.

2 Jun 2015: Separated the two sides into separate actions. Having both apps referenced in one script was causing problems.

19 Feb 2016: Added third config option to support iTerm2 v2.9 and above, which has breaking AppleScript changes.

Credits
-------
Original extension and icon created by [James Smith](https://twitter.com/smithjw/status/244757999665700864).

iTerm option added by [honnix](https://github.com/honnix).

