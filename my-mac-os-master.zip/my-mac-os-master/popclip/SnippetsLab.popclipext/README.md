# SnippetsLab

Service extension to send the text to SnippetsLab.

Originally created by [Alx Stu](https://github.com/alxstu).  
New icon (based in SnippetsLab icon) made by Nick Moore.