# YouTube

This extension searches for the selected text on youtube.com.
