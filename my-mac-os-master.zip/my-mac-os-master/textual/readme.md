# Night Blue theme for [Textual](https://www.codeux.com/textual/)

I love IRC and hanging out in various Freenode channels.

I wasn't happy with any of the default themes Textual comes with so I made this theme. Here is how it looks:

![](https://i.imgur.com/YgNVUMH.png)

I am using `Lucida Sans Regular` font.

## Install

To install the theme, download the Night Blue folder attached [here](Night%20Blue).

Then go to Textual app. Go to preferences and in Styles click on `Browse Styles` here:

![](https://i.imgur.com/cX0Z20c.png)

Put the downloaded folder inside the folder. You can read [this](https://help.codeux.com/textual/Styles.kb) for more information.
