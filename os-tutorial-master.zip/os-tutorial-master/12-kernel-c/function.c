int my_function() {
    return 0xbaba;
}
