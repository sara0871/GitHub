void func() {
    char* string = "Hello";
}
