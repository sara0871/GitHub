import { React, Inferno, ReactDOM } from '../src/infact'
import Demo from './demo'

import './index.html'

ReactDOM.render(
  <Demo />,
  document.getElementById('root')
)
