module.exports = require('./lib/inferno/index.js')
