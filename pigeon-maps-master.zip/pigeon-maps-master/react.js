module.exports = require('./lib/react/index.js')
