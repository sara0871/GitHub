module.exports = require('./dist/Sticky');
