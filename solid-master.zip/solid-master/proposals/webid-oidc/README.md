# WebID-OIDC spec proposal

Moved to https://github.com/solid/webid-oidc-spec
