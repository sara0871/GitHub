# Decentralized Authentication Glossary

Moved to https://github.com/solid/webid-oidc-spec#decentralized-authentication-glossary
