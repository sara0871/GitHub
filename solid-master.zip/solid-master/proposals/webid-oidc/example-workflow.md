# WebID-OIDC Detailed Sign In Workflow

Moved to https://github.com/solid/webid-oidc-spec/blob/master/example-workflow.md
