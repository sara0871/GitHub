---
name: Feature request
about: Suggest an idea for Sourcegraph

---

#### Feature request description

<!-- A description of what feature you would like. -->

#### Is your feature request related to a problem? If so, please describe.

<!-- A description of what the problem is. Ex. I'm always frustrated when [...] -->

#### Describe alternatives you've considered.

<!-- A description of any alternative solutions or features you've considered. -->

#### Additional context

<!-- Add any other context or other information you'd like to provide. -->
