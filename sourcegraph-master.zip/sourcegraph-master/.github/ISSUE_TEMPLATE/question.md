---
name: Question
about: Ask a question about Sourcegraph

---

#### Question description

<!-- Type your question here. -->

#### Is your question related to a problem? If so, please describe or link to another issue.

<!-- A description of what the related problem is. Ex. I'm always frustrated when [...] -->

#### Additional context

<!-- Add any other context or other information you'd like to include. -->
