package assets

import "net/http"

// Assets contains the browser-side assets.
var Assets http.FileSystem
