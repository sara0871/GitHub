// Package db contains PostgreSQL DB-backed stores.
package db
