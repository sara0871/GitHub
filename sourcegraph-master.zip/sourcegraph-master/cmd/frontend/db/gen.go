package db

// $PGHOST, $PGUSER, $PGPORT etc. must be set to run this generate script.
//go:generate go run schemadoc/main.go schema.md
