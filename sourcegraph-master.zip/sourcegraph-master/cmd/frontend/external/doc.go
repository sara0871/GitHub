// This is a parent package whose sub-packages exist solely to export certain types and variables
// from internal packages. An internal package should *never* import a sub-package of this package.
package external
