// Package graphqlbackend implements the GraphQL API.
package graphqlbackend
