package graphqlbackend

//go:generate go run schema_generate.go
