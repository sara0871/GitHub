// Package graphqlutil contains utilities for working with GraphQL.
package graphqlutil
