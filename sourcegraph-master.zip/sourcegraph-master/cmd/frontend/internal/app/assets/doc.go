// Package assets contains static assets for the front-end Web app. It should be imported for
// side-effects.
package assets
