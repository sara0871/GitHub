//go:generate go run assets_generate.go

package assets
