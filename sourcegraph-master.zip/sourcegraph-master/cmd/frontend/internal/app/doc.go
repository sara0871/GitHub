// Package app contains the front-end Web application.
package app
