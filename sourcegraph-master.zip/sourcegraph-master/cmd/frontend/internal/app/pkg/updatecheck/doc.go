// Package updatecheck provides a client and HTTP handler for checking and serving
// software update information for Sourcegraph versions.
package updatecheck
