// Package templates contains Go HTML template files for the front-end
// Web app.
package templates
