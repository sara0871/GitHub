//go:generate go run data_generate.go

package templates
