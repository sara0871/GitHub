// Package userpasswd implements builtin username-password authentication and signup.
package userpasswd
