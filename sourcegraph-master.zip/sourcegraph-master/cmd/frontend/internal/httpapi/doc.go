// Package httpapi contains the HTTP API.
package httpapi
