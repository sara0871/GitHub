// Package handlerutil contains common helper functions used by both
// the app and API HTTP handlers.
package handlerutil
