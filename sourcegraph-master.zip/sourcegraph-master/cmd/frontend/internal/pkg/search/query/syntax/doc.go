// Package syntax parses search queries into parse trees. Most clients will
// use the parent package instead of this package.
//
// This package is derived from http://github.com/bcampbell/qs (see NOTICE).
package syntax
