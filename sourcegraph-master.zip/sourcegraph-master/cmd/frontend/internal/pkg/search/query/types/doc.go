// Package types contains facilities for checking the validity
// and typesafety of search queries.
package types
