// Package registry contains a partial implementation of the extension registry.
package registry
