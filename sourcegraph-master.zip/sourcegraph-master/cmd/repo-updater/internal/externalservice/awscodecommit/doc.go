// Package awscodecommit implements an AWS CodeCommit API client.
package awscodecommit
