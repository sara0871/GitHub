// Package github implements a GitHub API client.
package github
