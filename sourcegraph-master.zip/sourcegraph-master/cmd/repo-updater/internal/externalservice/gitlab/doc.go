// Package gitlab implements a GitLab API client.
package gitlab
